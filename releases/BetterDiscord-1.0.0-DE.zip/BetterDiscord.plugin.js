/**
 * @name Bestes Discord
 * @author lol8908-rgb
 * @version 1.0.0
 * @description Ein umfassendes BetterDiscord Plugin für alle Discord-Verbesserungen mit UI-Verbesserungen, Hintergrundbild-Verwaltung und vielen neuen Features
 * @website https://github.com/lol8908-rgb/Better-Discord
 * @source https://github.com/lol8908-rgb/Better-Discord
 */

const { Webpack } = BdApi;

class BetterDiscord {
  constructor() {
    this.settings = BdApi.loadData("BetterDiscord", "settings") || {
      backgroundColor: "#36393F",
      backgroundImage: "",
      backgroundOpacity: 1,
      roundedCorners: true,
      customFont: "Whitney",
      fontSize: 16,
      enableAnimations: true,
      enableGlassmorph: false,
      enableCompactMode: false,
    };
    
    this.cssId = "better-discord-css";
  }

  start() {
    console.log("[Better Discord] Plugin started");
    this.injectCSS();
    this.createSettingsPanel();
    this.applySettings();
    this.setupBackgroundManager();
  }

  stop() {
    console.log("[Better Discord] Plugin stopped");
    this.removeCSS();
  }

  /**
   * Erstellt das Settings Panel
   */
  createSettingsPanel() {
    const panel = document.createElement("div");
    panel.id = "better-discord-settings";
    panel.style.display = "none";
    panel.innerHTML = this.getSettingsPanelHTML();
    document.body.appendChild(panel);
    this.setupSettingsPanelListeners();
  }

  /**
   * Gibt das HTML für das Settings Panel zurück
   */
  getSettingsPanelHTML() {
    return `
      <div class="bd-settings-modal">
        <div class="bd-settings-header">
          <h2>🎨 Better Discord Einstellungen</h2>
          <button class="bd-close-btn" onclick="document.getElementById('better-discord-settings').style.display='none'">✕</button>
        </div>
        
        <div class="bd-settings-content">
          
          <!-- Hintergrund Einstellungen -->
          <div class="bd-settings-section">
            <h3>🖼️ Hintergrund</h3>
            
            <div class="bd-setting-item">
              <label for="bg-image-input">Hintergrundbild URL oder Datei:</label>
              <input type="text" id="bg-image-input" class="bd-input" placeholder="https://example.com/image.jpg" value="${this.settings.backgroundImage}">
              <input type="file" id="bg-image-file" accept="image/*,.gif" style="margin-top: 10px;">
              <small>Unterstützt: JPG, PNG, GIF (auch animiert)</small>
            </div>

            <div class="bd-setting-item">
              <label for="bg-opacity">Deckkraft: <span id="opacity-value">${(this.settings.backgroundOpacity * 100).toFixed(0)}%</span></label>
              <input type="range" id="bg-opacity" min="0" max="1" step="0.1" value="${this.settings.backgroundOpacity}" class="bd-slider">
            </div>

            <div class="bd-setting-item">
              <label for="bg-color">Hintergrundfarbe:</label>
              <input type="color" id="bg-color" class="bd-color-picker" value="${this.settings.backgroundColor}">
            </div>
          </div>

          <!-- UI Verbesserungen -->
          <div class="bd-settings-section">
            <h3>✨ UI Verbesserungen</h3>
            
            <div class="bd-setting-item">
              <label>
                <input type="checkbox" id="rounded-corners" class="bd-checkbox" ${this.settings.roundedCorners ? "checked" : ""}>
                Abgerundete Ecken
              </label>
            </div>

            <div class="bd-setting-item">
              <label>
                <input type="checkbox" id="enable-animations" class="bd-checkbox" ${this.settings.enableAnimations ? "checked" : ""}>
                Animationen aktivieren
              </label>
            </div>

            <div class="bd-setting-item">
              <label>
                <input type="checkbox" id="glassmorph" class="bd-checkbox" ${this.settings.enableGlassmorph ? "checked" : ""}>
                Glassmorph Effekt (Experimental)
              </label>
            </div>

            <div class="bd-setting-item">
              <label>
                <input type="checkbox" id="compact-mode" class="bd-checkbox" ${this.settings.enableCompactMode ? "checked" : ""}>
                Kompakter Modus
              </label>
            </div>
          </div>

          <!-- Schriftart -->
          <div class="bd-settings-section">
            <h3>🔤 Schriftart</h3>
            
            <div class="bd-setting-item">
              <label for="font-select">Schriftart:</label>
              <select id="font-select" class="bd-select">
                <option value="Whitney" ${this.settings.customFont === "Whitney" ? "selected" : ""}>Whitney</option>
                <option value="Arial" ${this.settings.customFont === "Arial" ? "selected" : ""}>Arial</option>
                <option value="Segoe UI" ${this.settings.customFont === "Segoe UI" ? "selected" : ""}>Segoe UI</option>
                <option value="Roboto" ${this.settings.customFont === "Roboto" ? "selected" : ""}>Roboto</option>
                <option value="Verdana" ${this.settings.customFont === "Verdana" ? "selected" : ""}>Verdana</option>
              </select>
            </div>

            <div class="bd-setting-item">
              <label for="font-size">Schriftgröße: <span id="font-size-value">${this.settings.fontSize}px</span></label>
              <input type="range" id="font-size" min="12" max="20" step="1" value="${this.settings.fontSize}" class="bd-slider">
            </div>
          </div>

          <!-- Buttons -->
          <div class="bd-settings-footer">
            <button class="bd-btn bd-btn-primary" id="bd-save-btn">💾 Speichern</button>
            <button class="bd-btn bd-btn-secondary" id="bd-reset-btn">🔄 Zurücksetzen</button>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Richtet die Event-Listener für das Settings Panel ein
   */
  setupSettingsPanelListeners() {
    const opacitySlider = document.getElementById("bg-opacity");
    const fontSizeSlider = document.getElementById("font-size");
    const saveBtn = document.getElementById("bd-save-btn");
    const resetBtn = document.getElementById("bd-reset-btn");
    const fileInput = document.getElementById("bg-image-file");

    if (opacitySlider) {
      opacitySlider.addEventListener("input", (e) => {
        document.getElementById("opacity-value").textContent = `${(e.target.value * 100).toFixed(0)}%`;
      });
    }

    if (fontSizeSlider) {
      fontSizeSlider.addEventListener("input", (e) => {
        document.getElementById("font-size-value").textContent = `${e.target.value}px`;
      });
    }

    if (fileInput) {
      fileInput.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            document.getElementById("bg-image-input").value = event.target.result;
          };
          reader.readAsDataURL(file);
        }
      });
    }

    if (saveBtn) {
      saveBtn.addEventListener("click", () => this.saveSettings());
    }

    if (resetBtn) {
      resetBtn.addEventListener("click", () => this.resetSettings());
    }
  }

  /**
   * Speichert die Einstellungen
   */
  saveSettings() {
    this.settings = {
      backgroundColor: document.getElementById("bg-color").value,
      backgroundImage: document.getElementById("bg-image-input").value,
      backgroundOpacity: parseFloat(document.getElementById("bg-opacity").value),
      roundedCorners: document.getElementById("rounded-corners").checked,
      customFont: document.getElementById("font-select").value,
      fontSize: parseInt(document.getElementById("font-size").value),
      enableAnimations: document.getElementById("enable-animations").checked,
      enableGlassmorph: document.getElementById("glassmorph").checked,
      enableCompactMode: document.getElementById("compact-mode").checked,
    };

    BdApi.saveData("BetterDiscord", "settings", this.settings);
    this.applySettings();
    this.showNotification("✅ Einstellungen gespeichert!");
  }

  /**
   * Setzt alle Einstellungen zurück
   */
  resetSettings() {
    if (confirm("Alle Einstellungen auf Standard zurücksetzen?")) {
      this.settings = {
        backgroundColor: "#36393F",
        backgroundImage: "",
        backgroundOpacity: 1,
        roundedCorners: true,
        customFont: "Whitney",
        fontSize: 16,
        enableAnimations: true,
        enableGlassmorph: false,
        enableCompactMode: false,
      };
      BdApi.saveData("BetterDiscord", "settings", this.settings);
      location.reload();
    }
  }

  /**
   * Wendet die Einstellungen an
   */
  applySettings() {
    this.updateCSS();
  }

  /**
   * Verwaltet Hintergrundbilder und animierte GIFs
   */
  setupBackgroundManager() {
    if (this.settings.backgroundImage) {
      const appMount = document.querySelector("#app-mount");
      if (appMount) {
        appMount.style.backgroundImage = `url("${this.settings.backgroundImage}")`;
        appMount.style.backgroundSize = "cover";
        appMount.style.backgroundPosition = "center";
        appMount.style.backgroundAttachment = "fixed";
      }
    }
  }

  /**
   * Injiziert CSS für UI-Verbesserungen
   */
  injectCSS() {
    if (document.getElementById(this.cssId)) return;

    const css = document.createElement("style");
    css.id = this.cssId;
    css.textContent = `
      /* Better Discord Styles */
      
      #app-mount {
        background-color: ${this.settings.backgroundColor};
        ${this.settings.backgroundImage ? `background-image: url("${this.settings.backgroundImage}");` : ""}
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        opacity: 1;
      }

      /* Settings Modal */
      .bd-settings-modal {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(54, 57, 63, 0.95);
        border-radius: 12px;
        padding: 30px;
        z-index: 999999;
        max-width: 600px;
        width: 90vw;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        ${this.settings.enableGlassmorph ? "backdrop-filter: blur(10px);" : ""}
        border: 1px solid rgba(255, 255, 255, 0.1);
      }

      .bd-settings-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        border-bottom: 2px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 15px;
      }

      .bd-settings-header h2 {
        color: #fff;
        margin: 0;
        font-size: 24px;
      }

      .bd-close-btn {
        background: none;
        border: none;
        color: #fff;
        font-size: 24px;
        cursor: pointer;
        transition: transform 0.2s;
      }

      .bd-close-btn:hover {
        transform: scale(1.2);
      }

      .bd-settings-content {
        color: #fff;
      }

      .bd-settings-section {
        margin: 25px 0;
        padding: 15px;
        background: rgba(0, 0, 0, 0.2);
        border-radius: 8px;
        border-left: 4px solid #5865F2;
      }

      .bd-settings-section h3 {
        margin: 0 0 15px 0;
        color: #5865F2;
        font-size: 18px;
      }

      .bd-setting-item {
        margin: 15px 0;
      }

      .bd-setting-item label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: #ddd;
      }

      .bd-input,
      .bd-select {
        width: 100%;
        padding: 10px;
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #fff;
        border-radius: 6px;
        font-size: 14px;
        transition: border-color 0.3s;
      }

      .bd-input:focus,
      .bd-select:focus {
        outline: none;
        border-color: #5865F2;
        background: rgba(88, 101, 242, 0.1);
      }

      .bd-color-picker {
        width: 100%;
        height: 50px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 6px;
        cursor: pointer;
      }

      .bd-slider {
        width: 100%;
        height: 6px;
        border-radius: 3px;
        background: rgba(255, 255, 255, 0.1);
        outline: none;
        -webkit-appearance: none;
      }

      .bd-slider::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: #5865F2;
        cursor: pointer;
        transition: transform 0.2s;
      }

      .bd-slider::-webkit-slider-thumb:hover {
        transform: scale(1.2);
      }

      .bd-slider::-moz-range-thumb {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: #5865F2;
        cursor: pointer;
        border: none;
      }

      .bd-checkbox {
        width: 20px;
        height: 20px;
        margin-right: 10px;
        cursor: pointer;
        accent-color: #5865F2;
      }

      .bd-settings-footer {
        display: flex;
        gap: 10px;
        margin-top: 25px;
        padding-top: 20px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
      }

      .bd-btn {
        flex: 1;
        padding: 12px;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
      }

      .bd-btn-primary {
        background: #5865F2;
        color: white;
      }

      .bd-btn-primary:hover {
        background: #4752C4;
        transform: translateY(-2px);
      }

      .bd-btn-secondary {
        background: rgba(255, 255, 255, 0.1);
        color: white;
        border: 1px solid rgba(255, 255, 255, 0.2);
      }

      .bd-btn-secondary:hover {
        background: rgba(255, 255, 255, 0.15);
      }

      /* UI Verbesserungen */
      ${this.settings.roundedCorners ? `
        .message:hover,
        .messageContent:hover {
          border-radius: 12px;
        }
        
        .container-1giJPf {
          border-radius: 16px;
        }
      ` : ""}

      ${this.settings.enableAnimations ? `
        * {
          transition: all 0.2s ease-in-out !important;
        }
      ` : ""}

      ${this.settings.enableCompactMode ? `
        .message {
          margin-bottom: 4px;
        }
        
        .messageContent {
          padding: 2px 4px;
        }
      ` : ""}

      /* Font */
      body {
        font-family: ${this.settings.customFont}, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        font-size: ${this.settings.fontSize}px;
      }

      /* Glassmorph */
      ${this.settings.enableGlassmorph ? `
        .container-1giJPf,
        .layer-3KLMtG,
        [class*="sidebar"] {
          background: rgba(255, 255, 255, 0.1) !important;
          backdrop-filter: blur(20px) !important;
          border: 1px solid rgba(255, 255, 255, 0.2) !important;
        }
      ` : ""}

      /* Benachrichtigungen */
      .bd-notification {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: rgba(88, 101, 242, 0.9);
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        z-index: 999999;
        animation: slideIn 0.3s ease-in-out;
      }

      @keyframes slideIn {
        from {
          transform: translateX(400px);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
    `;

    document.head.appendChild(css);
  }

  /**
   * Entfernt das injizierte CSS
   */
  removeCSS() {
    const css = document.getElementById(this.cssId);
    if (css) css.remove();
  }

  /**
   * Updated das CSS mit aktuellen Einstellungen
   */
  updateCSS() {
    this.removeCSS();
    this.injectCSS();
    this.setupBackgroundManager();
  }

  /**
   * Zeigt eine Benachrichtigung an
   */
  showNotification(message) {
    const notification = document.createElement("div");
    notification.className = "bd-notification";
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
      notification.style.animation = "slideIn 0.3s ease-in-out reverse";
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }

  getSettingsPanel() {
    return this.getSettingsPanelHTML();
  }
}

if (!window.BetterDiscordPlugin) {
  window.BetterDiscordPlugin = new BetterDiscord();
}

module.exports = class BetterDiscordPlugin {
  getName() {
    return "Better Discord";
  }

  getDescription() {
    return "Ein umfassendes BetterDiscord Plugin mit UI-Verbesserungen, Hintergrundbild-Verwaltung und vielen neuen Features";
  }

  getVersion() {
    return "1.0.0";
  }

  getAuthor() {
    return "lol8908-rgb";
  }

  start() {
    window.BetterDiscordPlugin.start();
  }

  stop() {
    window.BetterDiscordPlugin.stop();
  }

  getSettingsPanel() {
    return window.BetterDiscordPlugin.getSettingsPanel();
  }
};
